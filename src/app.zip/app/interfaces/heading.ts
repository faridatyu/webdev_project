export interface Heading {
  id: number;
  section: number;
  name: string;
  description: string;
  // subtopics: number[];
}
