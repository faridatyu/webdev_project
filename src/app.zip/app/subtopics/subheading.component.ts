import { Component, OnInit, Input } from '@angular/core';
import { Heading } from '../interfaces/heading';
import { ApiService } from '../services/api.service';
import { Subtopic } from '../interfaces/subheading';

@Component({
  selector: 'app-subtopics',
  templateUrl: './subheading.component.html',
  styleUrls: ['./subheading.component.css']
})
export class SubheadingComponent implements OnInit {
  @Input() topic: Heading;
  subtopics: Subtopic[];
  showComponent = false;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.getSubtopics();
  }

  getSubtopics(): void {
    this.apiService.getSubtopicsByTopicId(this.topic.id)
      .subscribe(subtopics => this.subtopics = subtopics);
  }

  showCreateComponent(): void {
    if (this.showComponent) {
      this.showComponent = false;
    }
    else {
      this.showComponent = true;
    }
  }

  delete(subtopicId): void {
    this.apiService.deleteSubtopic(subtopicId).subscribe(res => {
      window.location.reload();
    });
  }
}
