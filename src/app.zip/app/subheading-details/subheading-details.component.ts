import { Component, OnInit } from '@angular/core';
import { Subheading } from '../interfaces/subheading';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ApiService } from '../services/api.service';
import {SubheadingComponent} from '../subheading/subheading.component';

@Component({
  selector: 'app-subheading-details',
  templateUrl: './subheading-details.component.html',
  styleUrls: ['./subheading-details.component.css']
})
export class SubheadingDetailsComponent implements OnInit {
  subheading: Subheading;

  constructor(private route: ActivatedRoute,
              private apiService: ApiService,
              private location: Location) { }

  ngOnInit(): void {
    this.getSubtopic();
  }

  getSubtopic(): void {
    const id = +this.route.snapshot.paramMap.get('subtopicId');
    this.apiService.getSubtopicBySubtopicId(id)
      .subscribe(subtopic => this.subtopic = subtopic);
    this.subtopic.recipe.replace('\n', '<br>');
  }

  save(): void {
    this.apiService.updateSubtopic(this.subtopic, this.subtopic.id)
      .subscribe(() => this.goBack());
  }

  goBack(): void {
    this.location.back();
  }
}
