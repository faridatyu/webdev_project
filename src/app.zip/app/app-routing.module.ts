import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { TopicDetailsComponent } from './topic-details/topic-details.component';
import { SubheadingDetailsComponent } from './subheading-details/subheading-details.component';
import { AboutComponent } from './about/about.component';
import { RecipeComponent} from './recipe/recipe.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'about', component:  AboutComponent},
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: 'topics/:topicId/edit', component: TopicDetailsComponent },
  { path: 'subtopics/:subtopicId/edit', component: SubheadingDetailsComponent },
  { path: 'recipes', component: RecipeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
