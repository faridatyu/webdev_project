import { Injectable } from '@angular/core';
import { Heading } from '../interfaces/heading';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TopicService {
  private topicsUrl = 'api/topics';
  constructor(private http: HttpClient) { }
  getTopics(): Observable<Heading[]> {
    return this.http.get<Heading[]>(this.topicsUrl);
  }
}
